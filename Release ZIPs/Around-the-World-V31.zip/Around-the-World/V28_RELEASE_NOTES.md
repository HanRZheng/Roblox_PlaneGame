# Around the World V28

V28 focuses on eliminating disconnected aircraft visuals, making doors blend into the fuselage, improving landing-gear spacing, adding Spark Airport, and moving aircraft presentation to a configurable client-smoothed controller.

## Aircraft exterior

- Multi-axle main/body gear rows now use 1.12 tire diameters of longitudinal spacing. Adjacent rows retain a visible gap instead of overlapping.
- Tire width, wheel count, wheel diameter, aircraft stance, and authoritative contact calculations remain catalog-driven.
- Wing and tail components now derive their position from the local tapered chord, local surface center, thickness, sweep, and dihedral. This corrects the hovering slats, flaps, fairings, spoilers, ailerons, and elevators caused by root-chord offsets.
- Every tagged moving wing/tail visual names its connected surface. A one-time runtime audit reports `DisconnectedVisualCount` and `VisualConnectionAuditRevision` on the aircraft model.
- Passenger, overwing, and cargo doors use the painted-fuselage color. Passenger doors continue the livery stripe, and all doors use thin semitransparent seams and small flush handles.

## Client-smoothed visual controller

- `AircraftAnimationConfig.lua` contains angles, travel scales, direction inversion, sequencing, and rates for regional, narrow-body, mid-size, wide-body, long-haul, jumbo, and superjumbo aircraft.
- Every moving visual uses a `Motor6D` connected to `Root`; landing gear and control surfaces remain unwelded while belonging to one stable assembly.
- The client reuses the server's replicated flight-state Attributes. It does not create a second flight model.
- Ailerons, elevators, rudder, flaps, slats, spoilers/speed brakes, landing gear, gear doors, rolling wheels, nose-wheel steering, engine fans, wing flex/folding tips, and reversers update at render rate.
- Gear follows an ordered door-open, gear-move, door-close sequence.
- Smoothing is exponential and delta-time based. Animation parts are cached once, no Tweens or repeated searches are created per frame, and model connections are disconnected on removal.
- The server remains authoritative for position, inputs, lift, thrust, drag, mass, handling, collision, and gameplay state.

## Spark Airport and map

- Added Spark Airport (`SPK`), a two-gate regional airport on Ember International's Redstone island.
- Spark includes its own runway, connected taxiways, apron, terminal facilities, tower, and ground reserve.
- Ember's generated buildings and trees now respect the complete Spark airport reserve.
- The minimap includes SPK and renders the player marker as a real concave four-point dart made from geometry. It cannot fall back to a rectangle or missing-font glyph.

## Test checklist

1. Open `Around-the-World-V28.rbxlx` in Roblox Studio.
2. Stop Play/Test mode, open **View → Command Bar**, and run `require(game.ReplicatedStorage.SkyDeck.StudioWorldBuilder).Build()` once to generate the editable V28 world.
3. Press Play, spawn one regional aircraft and one heavy multi-axle aircraft, and inspect wheel-row spacing.
4. Cycle flaps, speed brakes (`X`), gear (`G`), engine power, taxi steering, and flight controls while watching the surfaces.
5. Confirm gear doors open before the gear moves and close after the movement finishes.
6. Spawn at SPK and verify its two gates, runway, taxiways, and Ember scenery clearance.
7. Inspect passenger/cargo doors from close range and verify the fuselage paint and livery remain visually continuous.
8. Watch the minimap through a full turn and confirm the concave dart remains short, broad, and unambiguous.

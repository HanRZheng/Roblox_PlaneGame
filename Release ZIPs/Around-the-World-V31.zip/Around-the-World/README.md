# Around the World — Roblox Studio Project

## V31 animated-gear, varied-terminal, and livery-readiness update

- Fixed the landing-gear visual regression by removing competing server/client Motor6D writes; the server still owns flight and gear state while clients exclusively render smooth cosmetic motion
- Restored an ordered door-open → eased gear-travel → door-close sequence for both extension and retraction, without changing flight physics or ground handling
- Added seven terminal silhouette styles across the ten airports, including dual-pier, stepped, T-pier, crescent, rotunda, ridge, and compact forms while preserving all gate and jetbridge alignment
- Added a safe `AircraftLiveryConfig` with server backups, explicit mesh targeting, UV validation, asset-ID validation, idempotent SurfaceAppearance reuse, per-mesh overrides, dry runs, and change reporting
- No livery was applied because the supplied target and IDs are placeholders; see `V31_LIVERY_READINESS_REPORT.md`
- Completed the required non-destructive bogie-tilt verification gate; no aircraft-specific values were guessed, and `V31_BOGIE_TILT_VERIFICATION.md` lists the one target/reference decision still needed

## V30 Green Grass, varied-runway, and A380 re-entry update

- Added Green Grass Airport (`GGA`) on a new Greenhaven island southwest of Alpine Ridge, separated by a verified water channel
- GGA has two intersecting runways, seven gates, full terminal/taxi/apron facilities, 32 surrounding buildings, and a 72-tree generation target
- Added data-driven runway heading offsets: Sunport uses two parallel runways crossed by a diagonal secondary, while Coral Bay and Green Grass use crossing pairs
- Ember and Skyline retain staggered parallel layouts, so multi-runway airports no longer all share one pattern
- Runway pavement, markings, designations, lights, taxi connections, minimap geometry and lineup guides, touchdown detection, terrain exclusion, and scenery reserves all share the new rotated placement data
- Added a hairline surface offset at crossing intersections to prevent coplanar runway z-fighting without creating a physical step
- Fixed A380 cockpit re-entry by replacing the seat-centered prompt with accessible left/right forward-door prompt anchors; all aircraft use the same ownership-checked solution
- Added `V30_AIRCRAFT_VISUAL_UV_REVIEW.md`. The required first pass made no aircraft visual changes and correctly stopped livery painting because no exact target, approved original concept, or usable non-mirrored UV template was supplied

## V29 detailed navigation map and aircraft-effects update

- Rebuilt the north-up minimap around the same sampled coastline data that generates each island, with shoreline rims, interior contours, terrain/city detail, exact runway footprints, and airport labels
- Added restrained magenta dashed runway-extension guides to both ends of every runway so players can identify and hold an approach centerline from farther away
- Replaced the map arrow with an original yellow top-down aircraft icon made from UI geometry; it has distinct swept wings and tailplanes, rotates with true heading, and does not depend on an external image or font glyph
- Added `AircraftEffectsConfig.lua` with per-aircraft/profile engine counts, light offsets, flash patterns, effect thresholds, rates, quality limits, and draw distances
- Rebuilt lighting and particles around cached Attachments at the real wingtip, tail, engine-exhaust, wheel, and landing/taxi-light locations
- Added steady red/green/white navigation lights, white wingtip strobes, red upper/lower beacons, landing/taxi/turnoff/inspection/logo lights, fan blur, subtle exhaust, humid wingtip condensation, altitude-gated contrails, wet-runway spray, and brief hard-touchdown-only tire smoke
- The controller reuses existing electrical, engine, weather, flap, gear, speed, altitude, landing-phase, and touchdown-load state; it creates no second flight system and changes no flight physics
- Aircraft descendants are cached once, distance and quality gates suppress expensive effects, update-folder lookups are cached, and all per-aircraft connections/effects are cleaned up at removal

## V28 aircraft-connection, door, airport, map, and visual-animation update

- Separated every longitudinal row in multi-axle main/body landing-gear trucks by 1.12 tire diameters, leaving a visible gap while preserving real wheel counts, tire thickness, and contact geometry
- Repositioned slats, flaps, flap-track fairings, ailerons, spoilers, and elevators from their local wing/tail chord and surface height; added a connection audit so no tagged moving visual silently loses its parent surface
- Added two-gate Spark Airport (SPK) on Ember International's Redstone island, with its own runway, taxiways, apron, terminal, tower, and protected scenery reserve
- Made passenger, overwing, and cargo doors use the fuselage paint, restrained recessed seams, flush handles, and livery continuation instead of contrasting slabs
- Replaced the minimap marker with a true geometry-rendered concave dart matching the supplied short, broad silhouette; it has no Unicode glyph or rectangular fallback
- Added `AircraftAnimationConfig.lua`, Root-connected `Motor6D` visual rigs, and a client-smoothed controller for ailerons, elevators, rudder, flaps, slats, spoilers/speed brakes, ordered gear/door motion, wheels, steering, fans, wing flex, and reversers
- All V28 visual interpolation reuses server-authoritative Attributes, caches model parts once, uses delta-time exponential smoothing, creates no per-frame Tweens/searches, and cleans up its connections when an aircraft is removed
- Flight physics, lift, thrust, drag, mass, input behavior, and collision logic are unchanged by the new client visual layer

## V27 tire, nose, runway-layout, minimap, and PBR update

- Replaced hard-coded thin wheel widths with aircraft-variant tire aspect ratios; main and nose tires now scale to realistic width-to-diameter proportions while preserving wheel diameter, ground height, wheel count, and flight physics
- Added three tread bands per tire, correctly inset hubs and brake discs, and widened each axle/truck to match the thicker paired tires
- Reduced the Frame-built minimap direction pointer from 30×26 to 24×21 pixels while preserving its readable concave arrow shape
- Staggered second and third runways by 260 studs; runway pavement, diagonal connector taxiways, touchdown detection, protected terrain corridors, and minimap markings share the same placement data
- Added recessed family-specific cockpit glazing, smoother crown/chin transitions, adjusted radome fairings, lightning-diverter strips, angle-of-attack vanes, an ice detector, and avionics access panels
- Rebuilt `AircraftMaterialConfig.lua` around nine configurable material classes, including safe asset-ID preservation, an inspection report, missing-map reporting, and an idempotent apply function
- Added `V27_PBR_MATERIAL_REPORT.md` with the current asset audit, empty upload fields, and map-content guidance

## V26 island, Skyline Regional, and aircraft mesh-production update

- Replaced repeated circular islands with five area-preserving coastline profiles: elongated teardrops, ridges, broad lobes, bay lobes, and an asymmetric multi-lobed Skyline island
- Rotated the closest coastlines to retain visible water channels while keeping airport cores, runways, taxiways, terminals, and approach paths protected
- Added Skyline Regional (SKR), a separate three-gate airport sharing Metropolis Island with Skyline International
- Rebuilt the map island silhouettes to match the new geography and replaced the missing-font arrow with a compact Frame-built direction pointer that cannot render as a rectangle
- Added a non-running aircraft mesh manifest and validator for Blender replacements, including exact import envelopes, naming, pivots, collision/mass checks, wheel counts, and verified tire thickness targets where application data is available
- Added `AIRCRAFT_MESH_REPLACEMENT_SPEC_V26.md`; the current aircraft exterior remains unchanged as required by the non-destructive technical-art task

## V25 airports, aircraft silhouette, effects, and performance update

- Added three runways and connected taxiways at Sunport and Skyline, plus two at Ember and Coral Bay; terrain, city placement, scenery checks, touchdown detection, and the bird's-eye map understand every runway
- Replaced the long map pointer with a compact broad chevron based on the supplied reference, without a long course tail or center dot
- Rebuilt the aircraft nose taper, radome/chin blend, tail cone transition, vertical stabilizer, and rudder to remove the oversized triangular V24 tail and blunt nose silhouette
- Replaced blocky outer tips with smooth tapered sections; the Boeing 757-200 and 767-300ER use the tall swept blended-winglet style selected in the supplied photos
- Rebuilt spoilers as tapered multi-strip panels and fixed `X`: speed brakes now deploy on the ground or in flight and add real drag and sink instead of being visual-only
- Added type-specific handling profiles for regional, narrow-body, mid-size, wide-body, long-haul, jumbo, and superjumbo aircraft
- Added an `A / ALT HOLD` button that captures the current airborne altitude and makes smooth, safety-limited corrections
- Added `L`-controlled exterior lighting with steady navigation lights, double-flash beacons/strobes, directional landing/taxi/turnoff beams, wing inspection lights, and logo lighting
- Added client-side touchdown smoke, humid wingtip vortices, high-altitude contrails, engine heat haze, light rain, and wet-runway wheel spray
- Cut overlapping procedural nose/tail/wing sections substantially, disabled queries on cosmetic geometry, retained simple collision proxies, and added client-side distance LOD

## V24 aircraft, jet-bridge, and takeoff-state update

- Fixed departures being mistaken for landings: touchdown detection now arms only after a real climb or a delayed descending airborne state
- Added family-specific procedural fuselage and tail silhouette profiles while preserving the unapproved wingtip geometry for the separate audit
- Rebuilt flaps, slats, spoilers, ailerons, elevators, and rudder around visual hinge pivots; panel counts now vary by aircraft family
- Added gradual pilot-controlled speed brakes (`X`), differential roll spoilers, automatic landing-rollout spoilers, and moving thrust-reverser cowls
- Added a PBR-ready material assignment layer with distinct painted-airframe, metal, glass, tire, and engine-interior classes; map IDs remain intentionally empty until original maps are uploaded
- Added enclosed accordion aircraft-door canopies to every jet bridge, with overlapping roofs, floors, sidewalls, and ribs so the canopy meets the bridge cab without a visible gap
- Added `V24_WINGTIP_AUDIT.md`; no wingtip replacement has been made because the 757-200 and 767-300ER factory-versus-retrofit choice still needs approval

## V23 wing, landing-gear, engine, flare, and city update

- Added spanwise wing twist, tapered thickness, data-driven in-flight wing flex, flex-aware slats/flaps/spoilers/ailerons, moving wingtip lights, and automatic ground folding for the Boeing 777-9 tips
- Rebuilt engine presentation around aircraft-family profiles, with tapered fan blades, rotating hubs/spinners, inner intake and fan-shroud detail, turbine/exhaust geometry, access panels, pylons, drain masts, and gradual fan spool/coast animation
- Added original idle, power, takeoff, reverse, and shutdown WAV layers; Roblox asset IDs intentionally remain empty until the experience owner uploads the included files and enters the returned IDs in `EngineAudioConfig`
- Expanded landing gear with visible oleo pistons, torque/steering hardware, brake calipers, compression-aware trucks and wheels, staggered door motion, existing wheel spin-up, and aircraft-catalog wheel-count verification
- Added approach aerodynamics that separate aircraft attitude from flight path: with landing configuration selected, the plane can remain modestly nose-up while continuing a controlled descent, then flare when the pilot pulls farther back
- Increased general island buildings from 30 to 46 per airport, added a protected landside neighborhood road grid at every airport, and expanded Skyline to a 99-building, 10-avenue/12-street district
- All new roads and towers remain on the negative-X landside district, beyond the runway/approach protection corridor; the existing safety checks still reject random scenery near movement areas and shorelines

## V22 terrain, runway, smooth-flight, and aircraft-architecture update

- Lengthened every runway: regional fields now span 3,000–3,400 studs, Coral Bay reaches 4,200, Sunport and Ember reach 4,600–4,700, and Skyline reaches 5,200 studs
- Added deterministic low rolling terrain to every island, capped at 46 studs and rejected unless its complete footprint clears the runway/approach corridor, airport facilities, and shoreline
- Replaced the tall Alpine and desert scenery forms with lower broad ridges and mesas that remain well to the side of the runway path
- Extended initial lift blending from 3.6 to 4.6 seconds, reduced the initial vertical impulse, and softened rotation response for a less sudden takeoff
- Extended main-gear loading to 0.92 seconds and nose-gear settling to 1.65 seconds, with softer suspension, wheel spin-up, spoiler deployment, and bogie settling
- Added the `Interior` aircraft container and moved `PilotSeat` into it while preserving seat and flight-system references
- Fixed cockpit re-entry by resolving the owning aircraft through the seat's ancestry instead of assuming the seat is a direct child of the aircraft
- Added four invisible, queryable, non-physical collision proxies for the fuselage, wings, and tail while retaining the existing scripted flight collision behavior
- Each player aircraft type creates one inert `ServerStorage/<Aircraft Name> BeforeVisualUpgrade` backup before V22 organization or collision-proxy changes

## V21 landing-gear and map-separation update

- Reduced the bird's-eye map island footprint and shoreline overdraw so the close island chain can no longer appear to connect Coral Bay to Skyline
- Added a distinct main-gear contact stage with visible nose-wheel clearance and a minimum 0.72-second main-gear dwell before nose-gear contact can begin
- Multi-axle main and body bogies now hang at a natural data-driven angle in flight, pivot as one assembly, and settle smoothly onto all axles during touchdown
- Main-gear contact calculations now include the lowered rear axle of a tilted bogie, keeping the visual wheels and touchdown plane synchronized
- Aircraft visual geometry and materials were intentionally left unchanged pending approval of the separate V21 technical-art audit

## V20 Skyline International and world-map update

- Added **Skyline International (SKY)** on the new Metropolis Island: a full 14-gate terminal, large urban airport footprint, 63-building high-rise district, street grid, boulevard, glass towers, rooftop structures, and obstruction beacons
- All seven airports now have longer 2,200–3,800-stud runways widened from 170 to 220 studs, plus paved shoulders, longer stopways, PAPI lights, and centerline/crossbar approach lighting
- Player aircraft use denser nose, tail, wing, and stabilizer geometry, with fixed engine guide vanes, static-discharge wicks, visible tire tread bands, brake discs, and steerable nose-wheel assemblies
- Takeoff rotation builds more gradually, lift blends over 3.6 seconds, and early climb response is softer without adding automatic rotation or climb inputs
- Main-gear contact blends into the suspension over 0.62 seconds, impact loading is softer, and nose-gear settling takes 1.25 seconds while remaining under player pitch control
- Rebuilt the corner map as a north-up bird's-eye view of the full world, including island shapes, shorelines, runways, airport labels, a coordinate grid, and all seven airports
- Replaced the ambiguous small triangle with a large outlined heading pointer, a visible course tail and position dot, plus a live numeric and compass-direction readout
- Expanded the ocean, cloud area, and flight boundary to include Skyline International while retaining the V19 land-reserve and seamless-pavement protections

## V19 seamless-world and heavy-airliner update

- Oversized Roblox geometry is now automatically divided into perfectly adjoining Parts below the engine limit; full islands, runways, taxiways, aprons, terminal slabs, roads, markings, and ground reserves no longer get silently shortened over water
- Each island is built from overlapping 1,200-stud land tiles with a sand shoreline underlay, keeping every airport object on visible ground
- Apron pavement and its recessed continuity layer are tiled across their full width, while the 210-stud bridge overlaps both apron and parallel taxiway to remove the grass and taxiway-entry gaps
- Takeoff rotation has a slower damped pitch rate, a 2.75-second lift transition, and frame-rate-independent response smoothing
- Approach response blends over a larger height range; softer gear suspension and a 0.92-second nose-strut settling phase make touchdown more gradual while leaving the flare and nose lowering to the player
- Airborne bank is limited to 34 degrees, rolls in and out more slowly, and changes heading at a heavier airliner rate
- The parking brake is slightly weaker, reducing abrupt stops without changing the brake control
- The `BELLY` camera now sits aft of the wing, uses a wider field of view, and looks forward beneath the fuselage so the rear main gear frames the runway like the supplied reference
- Aircraft retain verified real-world exterior dimensions and family-specific nose/cockpit profiles, now using up to 148 nose, 108 tail, 112 wing, and 64 stabilizer sections
- Added 26-blade fans, nacelle panel seams, belly pack inlets, service panels, ram-air outlets, torque links, side stays, a lower beacon, and extra body-mounted bogies on the A380 and 747
- Every generated aircraft is organized into `Root`, `Visual`, `Controls`, `Collision`, and `Effects`; static cosmetic parts are massless, non-collidable, and welded to `Root`, while landing gear and control surfaces remain independently animated and unwelded
- A reusable attribute-driven visual controller now owns flaps, slats, spoilers, ailerons, elevators, rudder, landing gear, rolling wheels, and engine fans without changing the server flight equations
- Landing-gear layouts now use explicit aircraft data instead of a size-based guess: wheel totals range from 6 on regional/narrow-body jets to 22 on the A380, with generated totals checked against the catalog at runtime

## V18 expanded-airport and realistic-landing update

- Every island is substantially larger and the six airports are spread farther apart; widened inland reserves keep the complete runway, stopways, apron, terminal, roads, buildings, trees, mountains, and mesas above land
- The connected ocean now spans roughly 80,000 studs and the playable square spans 84,000 studs
- A recessed oversized apron underlay and an explicit 210-stud-wide taxiway bridge seal both reported grass gaps: within the apron and between the apron and taxiway
- Player aircraft use up to 132 nose sections, 92 tail sections, 96 wing sections, and 54 stabilizer sections, with added windshield wipers, family-appropriate passenger and overwing exits, cargo doors, drain masts, an APU exhaust, and a visible tail-skid assembly
- Takeoff rotation uses aircraft-specific tail-clearance geometry: pitch authority eases near the safe limit and the nose cannot rotate far enough to strike the runway while the main gear is loaded
- Approach handling now blends continuously by runway height and speed, with gentle ground effect and no automatic flare or landing input
- Landing remains player-controlled through descent, flare, main-gear contact, nose lowering, and rollout
- Press `C` to select the new `BELLY` camera, an underside view that keeps the gear and touchdown area in sight for smoother manual landings
- Edit-mode maps are now V18-versioned, so the builder safely backs up an older generated map before creating the expanded layout

## V17 smooth-flight and animated-aircraft update

- Ground rotation now gains authority progressively with airspeed and uses damped pitch-rate inertia, removing the sudden nose-up step while keeping rotation completely player-controlled
- Lift builds over the first 2.15 seconds after wheel separation, smoothly blending pitch, roll, and vertical response from the runway model into free flight
- Main-gear touchdown preserves the aircraft's exact contact position and transfers sink energy into a spring-damped suspension instead of instantly zeroing the visual motion
- A dedicated 0.62-second nose-strut settling phase removes the last touchdown snap after the player manually lowers the nose
- Ailerons, elevators, and the rudder now move with pilot inputs; leading-edge slats extend with flaps and ground spoilers deploy after touchdown
- Engine fan blades spool and coast with engine power instead of remaining static
- Landing gear now includes nose-wheel hubs, axles, truck beams, and dual wheels on each main-gear axle; heavy aircraft receive three-axle bogies
- The land-safe airport layout is retained, including its corrected runways, taxiways, aprons, terminals, and inland scenery boundaries

## V16 land-safe airport and manual-contact update

- One shared airport-surface generator now builds both the saved Studio map and the live-server map, so runway, taxiway, stopway, and apron fixes cannot drift apart
- Every airport has a verified inland ground reserve; larger islands keep the longer runways, 200-stud stopways, terminals, aprons, roads, trees, and scenery out of the ocean
- Runways now include edge and center lines, paired threshold bars, runway numbers, aiming points, coded touchdown-zone bars, edge lights, and yellow-chevron stopways
- Wide concrete parallel taxiways use compact curved fillets instead of oversized circular pads, with center/edge lines, enhanced centerlines, four-bar holding positions, guard lights, and runway/taxiway signs
- Aprons overlap their taxiway pavement and use continuous recessed stand supports, closing the remaining grass seams; 0.72-stud, 42%-transparent slab seams make the tile pattern only slightly clearer
- Player aircraft now use up to 120 nose sections, 80 tail sections, 88 wing sections, and 48 stabilizer sections, with smoother radomes, denser leading edges, and cockpit glazing fitted to each aircraft family's actual nose cross-section
- Takeoff and touchdown are completely manual: the player controls rotation, liftoff, descent, flare, main-gear contact, and nose lowering, with no takeoff-grace phase, automatic flare, altitude hold, touchdown pull-down, or scripted nose drop
- Softer pitch and vertical-response damping near the runway plus slower gear-compression recovery reduce abrupt-looking takeoffs and wheel contact without creating control inputs for the player
- Edit-mode maps are versioned; running the builder backs up an older generated map in `ServerStorage → AroundTheWorldBackups` before creating V16

## V15 continuous-apron and fully manual-flight update

- Every runway and parallel taxiway is now 170 studs wide, with 120-stud runway connectors and broad, rounded junction pads sized for the full-scale A380
- A continuous paved apron route joins the parallel taxiway to every stand; recessed stand supports remove the grass gaps that used to break up the apron
- Large 115-stud concrete slabs cover each apron with extremely thin, 58%-transparent low-contrast seams, so the tile pattern is visible close up without distracting from stand and taxi markings
- Island radii and the connected ocean are larger again; roads are pulled farther inland, while trees, buildings, mountains, and mesas use strict shoreline clearance and movement-area exclusions
- Takeoff rotation, liftoff, climb pitch, final descent, flare, and main-gear contact are controlled by the player—there is no scripted takeoff pitch or automatic touchdown movement
- Ground steering now eases toward the player's command for rounder taxi turns, including slower steerable pushback with a -10-knot maximum and gradual coast-to-stop
- A lighter parking-brake force, slower engine spool-up, and reduced ground thrust produce a less abrupt takeoff roll
- Landing-gear compression gently absorbs wheel contact without pulling the aircraft down, while the player remains responsible for lowering the nose gear
- Player aircraft now use up to 100 nose sections, 72 tail sections, 80 wing sections, and 44 stabilizer sections, plus refined radome tips, chin fairings, cockpit brows, and 22-blade engines
- Edit-mode maps are versioned; running the builder backs up an older generated map in `ServerStorage → AroundTheWorldBackups` before creating V15

## V14 wide-airport and manual-touchdown update

- The shared V14 layout gives every airport a 130-stud runway, 130-stud parallel taxiway, and 86-stud runway connectors
- 380-stud gate spacing, 350 × 520-stud paved stands, and a larger apron are sized around the full-scale A380, the widest aircraft in the game
- Island radii and airport spacing are larger again; roads, trees, city buildings, mountains, and mesas use shoreline and aircraft-movement exclusion zones
- Terminals begin beyond the taxiway, sit on continuous foundations, and have supported gate concourses, structural columns, solid glass, and unobstructed entrances
- The connected ocean and world boundary now cover a roughly 51,000 × 51,000-stud area
- Gradual 3.4-second landing-gear movement with animated gear doors, plus progressive flap travel instead of instant position changes
- Smoother ground rotation and initial climb with no sudden vertical takeoff step
- Fully manual final descent, flare, and main-gear touchdown: the script detects wheel contact but never pulls the aircraft down or lowers the nose automatically
- Pushback accelerates gradually to a maximum of -10 knots, remains steerable, coasts to a stop, and leaves the parking brake off
- Up to 84-section player-aircraft noses, 64-section tail tapers, 72-section wings, and 40-section stabilizers, with added fuselage seams, flap-track fairings, and engine spinners
- Edit-mode maps are versioned; running the builder backs up an older generated map in `ServerStorage → AroundTheWorldBackups` before creating V14

## V13 manual-flight and expanded-islands update

- Six larger, more widely separated islands keep runway ends, ring roads, trees, and scenery safely above land
- The connected ocean and world boundary now span 37,000 studs, and shoreline scenery generation has a 260-stud safety margin
- 64-stud parallel taxiways, 48-stud connectors, and dedicated full-length concrete pads at every gate
- Steerable pushback using the normal left/right controls, followed by a gradual coast
- Fully manual approaches and flares: neutral pitch gently descends, and no invisible landing cushion holds the plane above the runway
- Smoother 4.5-second takeoff rotation, softer control response near the runway, gentle main-gear contact, and gradual nose-wheel settling
- Up to 68-section player-aircraft noses, 50-section tail tapers, 64-section wings, and 32-section stabilizers
- Thirteen aircraft-family nose and cockpit profiles covering all 20 airliners, with different taper, droop, window height, width, angle, spacing, and placement
- The continuous dark wraparound cockpit mask is exclusive to the A350; every other family keeps its own windshield proportions
- Better attached under-wing engine placement, denser fan detail, gear-door outlines, static ports, pitot probes, and smoother airframe surfaces

## V12 airport-space and smooth-flight update

- True L-shaped jetbridges: terminal tunnel, circular rotunda, perpendicular elbow, and aircraft cab
- Walkable curved rotundas with open passageways, framed glass, pivot bases, support wheels, and aircraft-side bumpers
- Gate spacing increased from 120 to 180 studs, with wider terminal frontage at every airport
- Aprons are wider and extend farther away from the terminal; taxiways are 56 studs wide with five roomy runway connectors
- Larger islands and expanded scenery exclusion zones keep trees, buildings, mountains, and Ember mesas away from aircraft operating areas
- Smaller distance-limited airport and aircraft labels; AI aircraft no longer carry obstructive world labels
- The `Enter cockpit` prompt automatically hides whenever the pilot seat is occupied
- 52-section noses, 44-section tail tapers, 56-section wings, 28-section stabilizers, detailed door frames, cargo doors, handles, and 16-blade engine fans
- Four-second progressive rotation, gentler vertical response, a longer flare, softer main-gear contact, and slower nose-wheel settling

## V11 realism and airport-layout update

- Smoother 44-station noses, 38-station tail tapers, 48-section wings, aligned raked tips/winglets, corrected cockpit glazing, rounded nacelle fairings, attached pylons, and an original Around the World livery
- Larger airport footprints with 120-stud gate spacing, scaled aprons, and relocated city buildings, trees, mountains, and Ember mesas
- Reference-inspired hollow jetbridges with rotundas, overlapping telescoping corridors, arched roof edges, side glazing, support columns, wheel bogies, and an unobstructed terminal passage
- Raised gate concourses and solid terminal curtain-wall glass with actual doorway openings
- Solid-aircraft obstacle checks prevent planes from passing through terminals, jetbridges, scenery, and buildings
- Ground aircraft that leave an island now contact the ocean and begin the sinking/return-to-menu sequence
- Interactive airport seats use an `E` prompt
- On-foot running: hold `Shift` or use the touch-friendly `RUN` button
- Re-enter your own aircraft through its `Enter cockpit` prompt to restore the flight HUD and camera
- Softer rotation and vertical response during the first seconds of takeoff

## V10 airport expansion

- Aircraft dimensions use Roblox's standard physical conversion of one stud per 0.28 metres, driven by each airliner's catalogued real-world length and wingspan
- Higher-resolution nose and tail shaping, denser swept wings, smoother stabilizers, wing-root fairings, radome seams, and pitot details
- Jetbridges now connect on the corrected left side of the parked aircraft
- Enterable terminals with automatic entrances and walkable interiors
- Airport-specific gate totals, including Sunport 13, Coral Bay 7, Green Grass 7, Ember 15, Skyline International 14, Skyline Regional 3, and Spark 2
- Check-in desks, gate seating, plants, ceiling lighting, lounges, restrooms, service desks, duty-free shops, cafes, restaurants, baggage claim, and security equipment
- Island ring roads, terminal access roads, parking lots, marked spaces, and parked cars
- Jumping out of the pilot seat now leaves the player in walking mode to explore; press `M` to return to the flight menu

Around the World is an original open-world Roblox airliner game inspired by the easy free-flight feel of PTFS. It generates a complete island world when the server starts.

## Included

- 20 selectable full-scale airliners with aircraft-family nose/cockpit profiles, high-resolution wings and stabilizers, detailed engines, windows, animated landing gear, and lights
- Nose-in terminal parking with the forward passenger door aligned beside a detailed glass-and-metal jetbridge
- Slow, steerable ground pushback using the `B` key or the on-screen PUSHBACK button, with a gradual coast-to-stop
- Gentler steering sensitivity and slower, smoother bank-angle changes
- 10 airports on 8 separate islands, including Green Grass Airport, Skyline International/Regional, and Spark Airport sharing Ember's Redstone island
- Parallel and selected crossing runway systems, taxiways, connectors, hold-short markings, terminal stands, and jet bridges
- Aircraft now spawn at a marked terminal gate instead of on the runway
- One continuous tiled ocean connecting every island without oversized Terrain operations
- A guaranteed safe island spawn prevents repeated character falls or drowning
- Island streets and windowed city buildings provide more detailed surroundings
- Terrain-specific palms, pines, and broadleaf trees built from detailed non-round silhouettes
- Layered translucent clouds with shaded undersides that aircraft can fly through
- A roughly 80,000-stud-wide connected ocean and 84,000-stud-wide flight area with airports spread across larger separate islands
- Protected runway safety corridors that keep generated city buildings clear of runways
- Taxiing, takeoff, free flight, stalls, landing, off-runway landing, and safe reset behavior
- Water-contact sequence with gradual sinking and an automatic return to the main menu
- More gradual engine spool-up and a slower, heavier takeoff roll
- Fully manual descent and flare control with no automatic pitch-up or invisible hover cushion
- Pilot-controlled main-gear contact and nose lowering, followed by a detected nose-gear rollout phase
- Corrected liftoff logic so rotation cannot be mistaken for a main-gear touchdown
- Server-authoritative multiplayer aircraft
- Orbiting/zoomable chase camera plus cockpit, wing, and underside `BELLY` landing cameras
- Stabilized camera tracking and smoothed flight inputs to prevent visible aircraft shaking
- Pilot-seat validation stops control input after the player exits; the aircraft continues neutrally while the camera follows the character
- AI aircraft traffic
- Airport spawn menu, HUD, mini-map, messages, and mobile controls
- No external models, paid assets, or copyrighted PTFS/Roblox game assets

## Open it in Roblox Studio

1. Open `Around-the-World-V31.rbxlx` in Roblox Studio.
2. Build the map in Edit mode using the instructions below.
3. Press **Play** when you want to test the game.
4. Choose an aircraft and airport, then press **Spawn Aircraft**.
5. To publish, use **File → Publish to Roblox As…** in Studio.

The `src` folder and `default.project.json` are also included for developers who prefer Rojo.

## Build and edit the map without Play mode

1. Make sure the game is **stopped**, not running in Play/Test mode.
2. Open **View → Command Bar** in Roblox Studio.
3. Paste this command and press Enter:

```lua
require(game.ReplicatedStorage.SkyDeck.StudioWorldBuilder).Build()
```

The complete world appears under `Workspace → SkyDeckWorld`. You can now use normal Studio tools to add, move, recolor, or delete objects and then save the place. Play mode will reuse this saved world instead of rebuilding or deleting it.

Running the command again preserves an existing V31 editable world. If it finds an older generated version, it moves that world to `ServerStorage → AroundTheWorldBackups` before creating the V31 layout. Only use `Build(true)` if you intentionally want to erase the current generated map and start it over.

## Simple controls

| Control | Action |
| --- | --- |
| Mouse | Pitch and roll in flight; steer on the ground |
| Right mouse drag | Freely rotate the chase camera 360° around the aircraft |
| Mouse wheel | Zoom from close-up to a distant external view |
| Middle mouse click | Reset the chase camera angle and zoom |
| `E` | Start or stop engines |
| `P` | Toggle parking brake |
| Hold `W` / `S` | Increase / decrease throttle |
| `B` | Start pushback up to -10 knots; steer normally, then press again to coast with the brake off |
| `G` | Gradually raise / lower landing gear |
| `F` | Gradually cycle flaps 0–3 |
| `A` | Toggle altitude hold and capture the current safe airborne altitude |
| `X` | Gradually extend / retract speed brakes; they now add aerodynamic drag |
| `L` | Toggle exterior navigation, beacon, strobe, landing, taxi, and inspection lights |
| `C` | Cycle chase, cockpit, wing, and underside `BELLY` landing cameras |
| `R` | Safely reset at the departure runway |
| `H` | Show the quick-start help panel |
| Hold `Shift` on foot | Run through terminals and airports |
| `E` at your cockpit prompt | Re-enter your aircraft after walking |

Mobile players get a flight joystick, throttle buttons, and touchable system controls.
Drag on the right side of a touch screen to rotate the chase camera, or pinch to zoom.

## First takeoff

1. Press `E` to start the engines.
2. Press `P` to release the parking brake.
3. Hold `W` until the throttle is high and the aircraft passes its stall speed.
4. Move the mouse upward to lift off.
5. Move the mouse left/right to bank and turn.

For landing, lower the gear, select landing flaps, and use the mouse to control the descent. V25 lets a modest nose-up attitude remain on a descending approach path; pull farther back shortly before contact to reduce the sink rate. Press `C` until `BELLY` appears for the underside view, touch the main gear first, then deliberately lower the nose. The game waits at least 0.90 seconds before accepting nose-gear contact, but it does not auto-flare or lower the nose for you. Takeoff is equally manual: reach rotation speed and command pitch before liftoff; landing detection stays disarmed during the initial climb and the tail-clearance limiter prevents an impossible runway strike.

This is an arcade-style game, not a real-world flight-training tool.

## Project structure

```text
src/
  ReplicatedStorage/SkyDeck/
    AircraftCatalog.lua
    AircraftAnimationConfig.lua
    AircraftSilhouetteConfig.lua
    AircraftMaterialConfig.lua
    AircraftHandlingConfig.lua
    AircraftEffectsConfig.lua
    AircraftEffectsController.lua
    AircraftLODController.lua
    AircraftVisualController.lua
    EngineAudioConfig.lua
    AirportCatalog.lua
    AirportLayout.lua
    AirportInteriors.lua
    AirportSurfaces.lua
    AirportTerrain.lua
    StudioWorldBuilder.lua
  ServerScriptService/
    SkyDeckServer.server.lua
  StarterPlayer/StarterPlayerScripts/
    SkyDeckClient.client.lua
```

The original V23 audio files and upload instructions are in `audio/`. Until you upload them to Roblox and paste the resulting IDs into `EngineAudioConfig.lua`, the sound objects remain safely muted.

The server script validates aircraft and airport codes, clamps all client controls, and owns aircraft movement. This makes the project safer to expand into a public multiplayer experience.

# V27 aircraft PBR material audit and upload guide

## Audit scope and result

`[AIRCRAFT_MODEL_PATH]` was left as a placeholder, so V27 applies the system to every aircraft created by the shared `createAirliner` builder.

The packaged V27 place contains no static MeshPart instance, TextureID, or SurfaceAppearance instance. Current live aircraft are generated at runtime from Parts and SpecialMeshes. Their visual material assignments are SmoothPlastic paint, Metal hardware, Glass windows, Rubber tires, and limited Neon lighting/screens. Therefore there are no existing PBR asset IDs to migrate in the current procedural fleet.

The new inspection path remains essential for future Blender imports. `AircraftMaterialConfig.Inspect(model)` records every imported MeshPart TextureID, every SurfaceAppearance map, every material assignment, and any duplicate SurfaceAppearance objects before application. `Apply(model)` leaves every non-empty existing ID untouched.

## Configured classes and missing uploads

All map fields below are deliberately empty. No asset ID has been invented or copied from another game.

| Material class | Intended response | Maps awaiting original uploads |
| --- | --- | --- |
| PaintedFuselage | Mostly nonmetallic paint with restrained gloss | Color, Normal, Roughness, Metalness |
| BareMetal | Metallic hardware with varied roughness, never uniform chrome | Color, Normal, Roughness, Metalness |
| Wings | Painted wing skin with panel and walk-zone variation | Color, Normal, Roughness, Metalness |
| EngineNacelles | Painted cowling with localized metal lips/panels | Color, Normal, Roughness, Metalness |
| RubberTires | Dark, fully nonmetallic, rough rubber | Color, Normal, Roughness, Metalness |
| CockpitWindows | Dark glossy glazing with subtle roughness variation | Color, Normal, Roughness, Metalness |
| PassengerWindows | Dark glazing, slightly less reflective than cockpit glass | Color, Normal, Roughness, Metalness |
| InteriorPanels | Nonmetallic plastic/composite panels | Color, Normal, Roughness, Metalness |
| InstrumentScreens | Dark display surface with a self-lit pixel mask | Color, Normal, Roughness, Metalness, Emissive |

## What each map should contain

- ColorMap: base color, livery, labels, and stains without baked lighting, highlights, or reflections.
- NormalMap: small-scale relief only—panel seams, fasteners, tire tread, anti-slip texture, or interior grain. Do not encode large silhouette changes.
- RoughnessMap: grayscale surface response, with white rough and black smooth. Tires should be bright/rough; clean glazing dark/smooth; paint and metal should vary rather than use one value everywhere.
- MetalnessMap: grayscale material identity. Bare unpainted metal is white; paint, rubber, glass, and plastic remain black. Painted fuselage panels must not become mirror-like.
- EmissiveMap: a black background with only illuminated instrument pixels, legends, and annunciators visible. Roblox SurfaceAppearance does not expose an EmissiveMap property, so V27 preserves this ID in `PBREmissiveMap` for the instrument-screen/effects workflow.

## Safe application behavior

1. Put original uploaded asset IDs only in the matching `Definitions.<Class>.Maps` fields in `AircraftMaterialConfig.lua`.
2. Optionally set a MeshPart's `PBRMaterialClass` attribute to one of the nine exact class names. Otherwise V27 classifies by conservative object-name rules.
3. Call `AircraftMaterialConfig.Inspect(model)` before applying and retain its report.
4. Call `AircraftMaterialConfig.Apply(model)`. It applies a map only when that SurfaceAppearance slot is empty.
5. Call `Apply(model)` again as an idempotency check. The managed SurfaceAppearance count must not increase.
6. Compare the post-apply inspection with the saved pre-apply report. Existing MeshPart TextureIDs and non-empty SurfaceAppearance IDs must match exactly.

Existing duplicate SurfaceAppearance objects are reported but not deleted or merged automatically, because doing so could discard an intentional asset assignment.

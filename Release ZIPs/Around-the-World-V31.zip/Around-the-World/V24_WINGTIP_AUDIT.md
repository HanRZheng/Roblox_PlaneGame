# Around the World V24 — Wingtip audit and proposed implementation

Status: **audit complete; no wingtip geometry changed**.

## Target and current hierarchy

The selectable aircraft are generated at runtime from `AircraftCatalog.lua`, so the effective target path is:

`Workspace.SkyDeckWorld.Aircraft.<AIRCRAFT_CODE>`

After the visual organizer runs, the current tip geometry is normally under:

- `Controls.FlightSurfaces.AlignedRakedWingTip-1`
- `Controls.FlightSurfaces.AlignedRakedWingTip1`
- `Controls.FlightSurfaces.AlignedWinglet-1` and `AlignedWinglet1` when `Winglet = true`
- `Controls.FlightSurfaces.LowerWingtipFence-1` and `LowerWingtipFence1` when `SplitWinglet` or `WingtipFence` is enabled
- `Controls.FlightSurfaces.LeftNavigationLight` and `RightNavigationLight`

The generator currently creates the same block-based raked base tip on every aircraft, then optionally adds the same generic upright device. That cannot accurately represent all the real designs below. It also makes the E2 look like it has a vertical winglet and makes the A380/737 MAX devices too generic.

## Identification result

| Aircraft | Confirmed or proposed wingtip type | Status |
|---|---|---|
| A220-300 | Integrated advanced, canted winglet | Confirmed family type |
| A319neo / A320neo / A321neo | 2.4 m Sharklet-style upturned device | Confirmed standard neo type |
| A330-900 | Curved, blended composite Sharklet inspired by A350 | Confirmed |
| A350-900 / A350-1000 | Smooth curved/swept winglet-type device blended into the outer wing | Confirmed family type; production-standard contour must follow the selected reference date |
| A380-800 | Compact wingtip fence/device, not a tall blended winglet | Confirmed family type |
| 737 MAX 8 / MAX 9 | Boeing Advanced Technology split winglet | Confirmed |
| 747-8 | Composite raked tip replacing the 747-400 winglet | Confirmed |
| 757-200 | Plain factory tip **or** optional APB blended-winglet retrofit | **Ambiguous — approval required** |
| 767-300ER | Plain factory tip **or** optional APB blended-winglet retrofit | **Ambiguous — approval required** |
| 777-300ER | Raked wingtip | Confirmed |
| 777-9 | Folding raked wingtip; 71.8 m extended and 64.8 m folded span | Confirmed |
| 787-8 / 787-9 | Long swept/raked composite tip continuously blended into the wing | Confirmed family type |
| E190-E2 / E195-E2 | Swept-back tip integrated into the high-aspect-ratio wing; no generic upright winglet | Confirmed by Embraer planning terminology |
| CRJ900 | Small canted upright winglet | Confirmed by the manufacturer planning views; final contour must be traced from the CRJ900 three-view |

Primary references:

- [Airbus aircraft-characteristics publications](https://www.aircraft.airbus.com/en/customer-care/fleet-wide-care/airport-operations-and-aircraft-characteristics/aircraft-characteristics)
- [Airbus A220 family — advanced winglets](https://www.airbus.com/en/products-services/commercial-aircraft/passenger-aircraft/a220-family)
- [Airbus wingtip-device overview](https://www.airbus.com/en/newsroom/news/2017-02-winglets-a-tip-top-solution-for-more-efficient-aircraft)
- [Airbus A330neo curved Sharklets](https://www.airbus.com/en/newsroom/press-releases/2018-02-new-a330-800-rolls-out-of-paintshop)
- [Boeing 737 MAX Advanced Technology winglets](https://www.boeing.com/commercial/737max/by-design)
- [Boeing 747-8 airport-planning document](https://www.boeing.com/content/dam/boeing/boeingdotcom/commercial/airports/acaps/748_REV_C.pdf)
- [Boeing 777-300ER airport-planning document](https://www.boeing.com/content/dam/boeing/boeingdotcom/commercial/airports/acaps/777_2lr_3er_f.pdf)
- [Boeing 777X folding-tip document](https://www.boeing.com/content/dam/boeing/boeingdotcom/commercial/airports/acaps/777X_Rev_F.pdf)
- [Boeing 757/767 baseline-versus-retrofit winglet spans](https://www.boeing.com/content/dam/boeing/boeingdotcom/commercial/airports/faqs/wingletspans.pdf)
- [Boeing official three-view list, including separate 757/767 winglet variants](https://www.boeing.com/commercial/airports/3-view)
- [Embraer E2 airport-planning manual — “swept back wingtip”](https://www.embraer.com/media/vmsjxvk5/e-jets-e2_apm_e-jetse2.pdf)
- [Bombardier CRJ900 airport-planning manual](https://customer.aero.bombardier.com/webd/BAG/CustSite/BRAD/RACSDocument.nsf/51aae8b2b3bfdf6685256c300045ff31/ec63f8639ff3ab9d85257c1500635bd8/%24FILE/ATTQF1EY.pdf)

## Geometry plan after approval

The current tips are procedural Parts and wedges. For genuinely smooth, accurate silhouettes, each distinct design should use a small Blender-authored visual MeshPart pair rather than more stacked blocks.

- Scale each left tip against the manufacturer's top/front/side views and the catalog's full wingspan. Do not invent dimensions not present in those views.
- Match leading- and trailing-edge sweep, cant, toe, taper, thickness, curvature, airfoil continuation, and the blend radius at the joint.
- Keep the outer wing and its physics/collision proxies unchanged.
- Object names: `WingtipVisual_L` and `WingtipVisual_R`; separate `WingtipHinge_L/R` only for the 777-9.
- Aircraft-local orientation: +X right, +Y up, -Z forward. Put each object origin at the wing/tip join; put the 777-9 origin on the real fold axis.
- Build the left side once, mirror with a Blender Mirror modifier, apply transforms, recalculate outward normals, use smooth shading with marked sharp edges, and avoid doubled centerline vertices.
- Export visual geometry as FBX with transforms applied, no armature, no animation, and no embedded textures. Import at the project scale of 1 stud = 0.28 m.
- Make imported MeshParts Massless, non-collidable, and non-touching. Preserve query behavior only where the existing light/gameplay logic needs it.
- Move the existing red/green navigation-light anchors to the verified extreme tip positions. Preserve light colors and animation scripts.
- For the 777-9, preserve the existing folding controller but drive the new tip mesh around the verified hinge pivot.
- Use a dedicated UV set and PBR maps created for this project; do not copy another game's assets.

## Approval blocker

Before wingtip implementation, choose one configuration for both optional-retrofit aircraft:

**Should the Boeing 757-200 and 767-300ER use their plain factory tips, or the optional Aviation Partners Boeing blended-winglet retrofit?**

No current wingtip instances will be renamed, moved, deleted, or replaced until that choice is approved.

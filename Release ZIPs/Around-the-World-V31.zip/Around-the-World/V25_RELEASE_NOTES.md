# Around the World V25

## Aircraft

- Rebuilt the procedural nose/chin/radome blend and replaced the oversized triangular tail with a tapered, swept, smoothly sectioned fin and rudder.
- Smoothed all outer wingtip transitions. The Boeing 757-200 and 767-300ER use the tall blended-winglet style selected from the supplied reference photos.
- Rebuilt spoilers as tapered panels. `X` now visibly deploys them on the ground or in flight and applies real drag and descent force.
- Added weight-class handling profiles, reduced overlapping visual sections, non-querying cosmetic geometry, and two local distance LOD levels.
- Added desktop and mobile altitude-hold buttons. `A` captures the current safe airborne altitude; hold disengages automatically near landing or an unsafe low-speed condition.

## Airports and map

- Sunport International: 3 runways.
- Skyline International: 3 runways.
- Ember International: 2 runways.
- Coral Bay Airport: 2 runways.
- Each added runway includes shoulders, stopways, markings, approach/PAPI/edge lights, a parallel taxiway, and inter-runway connectors.
- Expanded the affected islands and moved Skyline's high-rise district clear of the new movement area.
- The map renders all runways and uses a compact wide chevron heading pointer based on the supplied image.

## Lighting and effects

- Press `L` for exterior lights: navigation, beacon, strobe, landing, taxi, runway-turnoff, wing-inspection, and logo lights.
- Added client-side double-flash timing and directional beams.
- Added light rain, wet-runway spray, touchdown tire smoke, humid wingtip vortices, contrails, and engine heat haze.

## Test first

1. Open `Around-the-World-V25.rbxlx` and press Play.
2. On the ground, press `X` and confirm every spoiler panel rises gradually; press it again before takeoff.
3. Press `L` and inspect the lights at night by changing `Lighting.ClockTime` in Studio.
4. Test a regional aircraft and an A380/747 to compare banking, acceleration, rotation, and braking inertia.
5. Fly over Sunport, Skyline, Ember, and Coral Bay and verify every runway and connecting taxiway is on land and clear of buildings and terrain.

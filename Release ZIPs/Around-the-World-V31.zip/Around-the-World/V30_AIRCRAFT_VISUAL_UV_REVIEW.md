# V30 aircraft visual-quality and UV-readiness review

## Review status

This is the required non-destructive first pass. No aircraft instance, texture, material assignment, flight value, control surface, script, name, or hierarchy was changed.

The requested target still contains the unresolved placeholder `[AIRCRAFT MODEL PATH]`, and the approved livery still contains `[CONCEPT NAME]`. The earlier request mentioned United Airlines, but no authorized United wordmark, globe artwork, license, or approval package was supplied. Real United trademarks cannot be recreated from scratch under the stated livery rules.

The distributable place stores aircraft-generator scripts rather than a live aircraft under `Workspace`. At runtime the target pattern is:

`Workspace.SkyDeckWorld.Aircraft.<AIRCRAFT_CODE>`

One exact runtime model and aircraft code must be selected before a view-by-view Studio sign-off can be completed.

## Texture, material, and UV inspection

Current generated aircraft use Roblox `Part`, `WedgePart`, and `SpecialMesh` geometry. `makeSmoothEllipsoid` creates a spherical `SpecialMesh` under a normal `Part`; it does not create a `MeshPart` with an editable aircraft UV layout.

Source inspection found:

| Item | Before review | After review | Result |
|---|---:|---:|---|
| Generated-aircraft `MeshPart` objects | 0 | 0 | No change |
| Generated-aircraft `SurfaceAppearance` objects | 0 | 0 | No change |
| Existing aircraft `TextureID` values | 0 | 0 | No change |
| Configured PBR asset IDs | 0 | 0 | All map fields remain intentionally empty |
| Aircraft visual/physics corrections | 0 | 0 | Audit only |

`ReplicatedStorage.SkyDeck.AircraftMaterialConfig` safely supports painted fuselage, bare metal, wings, nacelles, tires, cockpit/passenger glass, interior panels, and instrument screens, but its ColorMap, NormalMap, RoughnessMap, MetalnessMap, and EmissiveMap fields are empty. It cannot apply a continuous livery to the current segmented Part exterior.

Conclusion: there is no correct UV template, and left/right fuselage UV uniqueness cannot be verified because no aircraft exterior UV set exists. Livery painting did not begin.

## Problems still visible or structurally likely

The following are source-backed findings. Silhouette judgments that require side, front, top, rear, and three-quarter renders remain pending the exact runtime target.

1. **No paintable continuous exterior.** Runtime paths such as `Workspace.SkyDeckWorld.Aircraft.<CODE>.Visual.Fuselage`, `NoseSection*`, `TailSection*`, `MainWingSection*`, and `EngineNacelle*` are separate Parts or SpecialMesh-bearing Parts. A high-quality continuous livery requires the planned Blender replacement MeshParts.
2. **No UV layout or material slots on the live procedural exterior.** Responsible source: `ServerScriptService.SkyDeckServer.makeAircraftPart`, `makeAircraftWedge`, and `makeSmoothEllipsoid`. Text or a logo painted now would require many disconnected surfaces and could stretch, misalign, or reverse.
3. **Potential close-range segmentation/seams.** Dense overlapping nose, tail, wing, panel-ring, door-seam, and fairing objects can produce visible steps or z-fighting at some view angles. Candidate runtime paths include `Visual.NoseSection*`, `Visual.TailSection*`, `Visual.FuselagePanelRing*`, `Visual.DoorSeam*`, and `Visual.NacellePanelSeam*`.
4. **Transparency sorting risk.** Separate `CockpitFrontPane*`, `CockpitSidePane*`, `CabinWindow*`, and `FanBlurDisc*` objects can sort imperfectly when layered over overlapping fuselage or engine pieces.
5. **High procedural object count.** Player aircraft use up to 48 nose stations, 42 tail stations, 54 wing sections, 30 stabilizer sections, individual windows, gear details, fan blades, lights, and effect anchors. Exact descendant counts vary by aircraft, engine count, decorative/player mode, and wheel count, so a numeric count cannot be honestly reported until the exact runtime model is selected.
6. **Effects cost is bounded but nonzero.** Every aircraft can include 16 light rigs, three engine particle types per engine, two wingtip-vortex emitters, wheel spray/smoke emitters, rain, and fan-blur discs. V29 already caches these instances and gates them by distance and quality.
7. **Moving-component direction needs a real Studio pass.** `Controls.FlightSurfaces`, `Controls.LandingGear`, and `Controls.EngineFans` use cached Root-connected `Motor6D` rigs and server-authoritative Attributes. Source cleanup exists, but correct direction, neutral return, intersections, and disconnected events must be watched on the chosen model.
8. **RenderFidelity cannot yet be assigned.** Current exterior objects are not MeshParts. Recommended settings for the future imported version are listed below; none were applied in this audit.

## Recommended corrections, pending approval

1. Select one exact aircraft code and replace only its `Visual` exterior with the object set in `AircraftMeshManifest`; retain Root, controls, collision proxies, effects, seats, attachments, and flight scripts.
2. Use `RenderFidelity.Precise` for the player aircraft's fuselage, nose/cockpit shell, wing roots, and tail silhouette. Use `Automatic` for nacelles, moving controls, landing gear, doors, wheels, and normal exterior detail. Reserve `Performance` for dedicated distant-traffic LOD meshes, not the nearby player-aircraft exterior.
3. Preserve the current LOD policy: hide fasteners, wipers, static ports, static wicks, drain masts, service panels, guide vanes, brake calipers, panel rings, mullions, and brows beyond roughly 760 studs; additionally hide individual cabin windows, door frames, pack inlets, pylon fillets, nacelle chevrons, tire tread pieces, and hubs beyond roughly 1,750 studs.
4. Consolidate tiny detail into normal/roughness maps where it does not need silhouette, collision, lighting, or animation. Keep doors, controls, landing gear, wheels, fans, lights, and effect attachments separate.
5. Run `AircraftMeshValidator` in a staging folder, then compare flight-state Attributes and the same control-input sequence before installing the new visuals.

## Exact Blender UV-template procedure

1. Choose one code from `AircraftMeshManifest` and model to its exact `LengthStuds`, `SpanStuds`, and `HeightStuds` envelope. Keep the Roblox convention: nose toward local `-Z`, right wing `+X`, top `+Y`, and Root at `0,0,0`.
2. Finish the approved exterior object set before unwrapping. Apply scale and rotation so every object reads scale `1,1,1`. Apply any Mirror modifier before the final UV verification.
3. Assign the established slots: `MAT_AirframePaint`, `MAT_Livery`, `MAT_BareMetal`, `MAT_CockpitGlass`, `MAT_CabinGlass`, `MAT_Rubber`, `MAT_GearMetal`, `MAT_Brake`, `MAT_EngineInterior`, `MAT_HeatShield`, and `MAT_LightLens`.
4. On the fuselage, place the principal longitudinal seams along the belly and crown where possible. Add controlled seams around the nose/radome, cockpit glazing, tail cone, doors, and major fairings. Unwrap with consistent texel density and minimal stretch.
5. Give the left and right fuselage sides separate, non-overlapping UV islands. Do not stack or mirror any island that can carry airline text, a symbol, a flag, registration, door marking, or asymmetric graphic. Generic underside parts, unmarked tires, and other non-readable symmetric parts may share UV space deliberately.
6. Place the left and right fuselage islands in clearly labeled halves of the texture sheet with both noses pointing in a documented direction. Do the same for left/right tail, nacelle, and winglet islands. Leave padding appropriate for mipmaps and avoid placing text across island boundaries.
7. Create the four established sets: `ATW_<CODE>_Exterior`, `ATW_<CODE>_Glass`, `ATW_<CODE>_Gear`, and `ATW_<CODE>_Interior`, using `_BaseColor`, `_Normal`, `_Roughness`, and `_Metalness` suffixes as applicable.
8. In Blender's UV Editor choose **UV → Export UV Layout**, export a transparent 4096×4096 PNG or SVG for each set, and keep all UVs visible. Save the `.blend` before painting.
9. Apply a temporary asymmetric verification grid containing `LEFT`, `RIGHT`, `L-NOSE`, and `R-NOSE`. Inspect both sides in Material Preview. All labels must read normally from outside the aircraft. Remove the test grid only after the mirrored-UV check passes.
10. Export selected objects as FBX with `Apply Scalings: FBX Unit Scale`, `Forward: Z Forward`, and `Up: Y Up`. In Studio's 3D Importer keep **Merge Meshes** off and preserve pivots. Import into staging, never over the live aircraft.
11. Confirm the Studio preview points the nose toward Roblox local `-Z`, run `AircraftMeshValidator`, inspect the imported UV grid from all required views, and verify every individual mesh remains below Roblox's triangle limit.

## Required Studio review still pending

After an exact model path is supplied, run the following without modifying the aircraft:

- Side, front, top, rear, and front-three-quarter screenshots at the same focal length
- Gear-up/down, flap, spoiler, rudder, elevator, fan, and wheel-motion checks
- `AircraftMaterialConfig.Inspect(model)` for actual MeshPart, SurfaceAppearance, TextureID, and map counts
- `AircraftMeshValidator.Validate(model, code)` for naming, pivots, collisions, anchoring, dimensions, and wheel count
- Client/server Output review for errors and disconnected events
- A controlled before/after playtest using identical inputs after a later approved correction pass

## Final approval checklist

- [ ] Exact aircraft code and Explorer path supplied
- [ ] One of the three original livery concepts explicitly approved by name
- [ ] Trademark permission supplied for any real airline marks, or an original fictional airline selected
- [ ] Correct non-mirrored UV template exported and verified
- [ ] Baseline object, light, particle, MeshPart, SurfaceAppearance, and connection counts recorded in Studio
- [ ] Five required exterior views captured
- [ ] Validator passes in staging
- [ ] Corrections approved before implementation
- [ ] Post-change object counts and identical-input flight test recorded

No livery image files, Roblox asset IDs, or aircraft corrections were created during this first pass.

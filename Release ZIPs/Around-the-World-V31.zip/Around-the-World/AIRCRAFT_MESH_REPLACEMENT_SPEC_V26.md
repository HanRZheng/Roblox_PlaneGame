# Around the World V26 — Aircraft mesh replacement specification

Status: specification and validator only. The existing procedural aircraft were not edited by this work.

## Target and measurement basis

`[AIRCRAFT_MODEL_PATH]` was not replaced with a concrete Explorer path. In this project, playable aircraft are generated at runtime under `Workspace.SkyDeckWorld.Aircraft/<AircraftCode>` rather than stored as a static model in the place file. A live `Model:GetBoundingBox()` measurement therefore is not available outside Roblox Studio.

The required envelopes below come from the canonical real-dimension data already used by `AircraftCatalog.lua`, at the project's established scale of 1 stud = 0.28 metres. They are the required V26 import scale. Before replacing any visual, run `AircraftMeshValidator.CaptureBoundingBox()` on both the old runtime aircraft and the new staging import and save both reports. Do not claim that the catalog envelope is a measured runtime box.

| Code | Exact variant | Length | Wingspan | Height |
|---|---|---:|---:|---:|
| A223 | Airbus A220-300 | 138.21 | 125.36 | 41.07 |
| A19N | Airbus A319neo | 120.86 | 127.86 | 42.00 |
| A20N | Airbus A320neo | 134.18 | 127.86 | 42.00 |
| A21N | Airbus A321neo | 158.96 | 127.86 | 42.00 |
| A339 | Airbus A330-900 | 227.46 | 228.57 | 59.96 |
| A359 | Airbus A350-900 | 238.57 | 231.25 | 60.89 |
| A35K | Airbus A350-1000 | 263.54 | 231.25 | 61.00 |
| A388 | Airbus A380-800 | 259.71 | 284.82 | 86.04 |
| B38M | Boeing 737 MAX 8 | 141.14 | 128.29 | 43.93 |
| B39M | Boeing 737 MAX 9 | 150.57 | 128.29 | 43.93 |
| B748 | Boeing 747-8 | 272.50 | 244.29 | 69.29 |
| B752 | Boeing 757-200 | 169.00 | 135.89 | 48.43 |
| B763 | Boeing 767-300ER | 196.21 | 169.89 | 56.61 |
| B77W | Boeing 777-300ER | 263.79 | 231.43 | 66.07 |
| B779 | Boeing 777-9 | 273.93 | 256.43 | 70.36 |
| B788 | Boeing 787-8 | 202.57 | 214.71 | 60.43 |
| B789 | Boeing 787-9 | 224.32 | 214.71 | 60.79 |
| E290 | Embraer E190-E2 | 129.43 | 120.43 | 38.29 |
| E295 | Embraer E195-E2 | 148.21 | 125.43 | 38.93 |
| CRJ9 | Bombardier CRJ-900 | 129.29 | 88.93 | 26.79 |

Dimensions are in studs and are ordered length, full span, total height. Span maps to Roblox local X, height to local Y, and length to local Z.

## Modeling standard

Build a separate exterior for each listed variant. Families may share a clean topology strategy, but not one generic nose, tail, wingtip, or landing gear stretched to every aircraft.

### Nose and cockpit

Implement the requested nose improvements as true custom geometry:

1. Use a separate nose mesh family for A220, A320, A330, A350, A380, 737, 747, 757, 767, 777, 787, E2, and CRJ. The 757 and 767 may share workflow but must not share the same final silhouette.
2. Construct each nose from smooth longitudinal splines and controlled cross-section loops. Maintain curvature continuity from constant-section fuselage through radome; avoid spheres, stacked ellipsoids, and visible station steps.
3. Cut a shallow, real opening for the cockpit windshield group. Recess glass behind the fuselage skin, include the center post and side frames in the airframe mesh, and match family-specific window rake, mask, eyebrow, and lower sill. Floating flat glass Parts are prohibited.
4. Validate front, side, top, and three-quarter silhouettes against an approved manufacturer three-view or reliable perpendicular photo before export. Where a dimension is unavailable, label the proportion as an estimate and request approval rather than inventing a measurement.

### Tail

Create a smoothly tapered tail cone with family-correct upsweep, APU exhaust, pressure-bulkhead transition, dorsal fairing, and tail-skid housing where applicable. The vertical stabilizer must have an airfoil section, correct leading/trailing-edge sweep, root blend, tip radius, and a separately pivoted rudder. Horizontal stabilizers need a tapered airfoil and separate elevators. CRJ9 alone uses its T-tail placement; the other listed variants use their verified conventional-tail layout. Remove the current triangular slab look and any abrupt fuselage-to-tail step.

### Tires and wheels

Tires must be rounded radial/bias tire meshes with a full sidewall, shoulder, tread crown, recessed hub, brake pack, and circumferential grooves. Never represent them as thin discs. The exact targets and verification state are stored in `AircraftMeshManifest.lua`; the validator checks diameter and width to an 8% visual-production tolerance.

Application-chart examples include 46 x 18-inch main tires on the 767-300, 40 x 14.5-inch mains on the 757-200, and 52 x 21-inch mains on the 777-300ER. These are converted to project studs in the manifest. A220, 777-9, and E2-specific entries remain marked for maintenance-manual verification rather than being presented as confirmed data. The imported aircraft must also contain exactly the catalog wheel count: 6, 10, 14, 18, or 22 as specified per variant.

Reference: [Goodyear Aviation 2022 application charts](https://www.goodyearaviation.com/resources/pdf/Application-Charts-2022.pdf) and [Bridgestone commercial-aircraft application data](https://www.bridgestone.com/products/aircraft/products/applications/). Operator/aircraft AMM data takes precedence if it identifies a different approved tire.

## Required Blender objects

Replace `<CODE>` with the catalog code and use two-digit sequence numbers.

Static exterior:

- `ATW_<CODE>_Fuselage`
- `ATW_<CODE>_Nose`
- `ATW_<CODE>_TailCone`
- `ATW_<CODE>_Wing_L`, `ATW_<CODE>_Wing_R`
- `ATW_<CODE>_Fin`
- `ATW_<CODE>_HStab_L`, `ATW_<CODE>_HStab_R`
- `ATW_<CODE>_Nacelle_01…04` and matching `ATW_<CODE>_Pylon_01…04`
- `ATW_<CODE>_CockpitGlass`, `ATW_<CODE>_CabinGlass`
- Optional fairings use `ATW_<CODE>_Fairing_<purpose>_<nn>`.

Moving flight controls:

- `CTRL_<CODE>_Aileron_L/R`
- `CTRL_<CODE>_Elevator_L/R`
- `CTRL_<CODE>_Rudder`
- `CTRL_<CODE>_Flap_L/R_<nn>`
- `CTRL_<CODE>_Slat_L/R_<nn>`
- `CTRL_<CODE>_Spoiler_L/R_<nn>`
- `CTRL_<CODE>_Fan_<nn>`
- `CTRL_<CODE>_Reverser_<nn>` when the exact nacelle has a visually moving translating cowl or cascade system
- `CTRL_B779_FoldingTip_L/R` for the 777-9 only

Landing gear:

- `GEAR_<CODE>_NoseStrut`, `GEAR_<CODE>_MainStrut_L/R`
- `GEAR_<CODE>_BodyStrut_L/R` only where required by the actual variant
- `GEAR_<CODE>_NoseDoor_<nn>`, `GEAR_<CODE>_MainDoor_L/R_<nn>`, and body-door equivalents
- `GEAR_<CODE>_Truck_Main_L/R` plus body trucks where applicable
- `GEAR_<CODE>_Wheel_01…22`, numbered nose wheels first, left main/body gear next, then right main/body gear

Every required object is one coherent mesh object, not a collection of cosmetic Roblox blocks. Use the Mirror modifier during modeling, apply it before export, and inspect normal direction and UV symmetry on both sides.

## Pivots and axes

The finished Roblox local convention is nose toward -Z, right wing +X, and top +Y. `Root` is at local 0,0,0 on the aircraft centerline. Keep every object transform applied at scale 1 and use object origins plus child `Attachment` named `PIVOT` at the exact same hinge/rotation origin.

| Moving object | Pivot location | Positive local axis |
|---|---|---|
| Aileron | Physical hinge line at forward edge | X along span |
| Elevator | Physical hinge line at forward edge | X along span |
| Rudder | Physical hinge line at forward edge | Y upward |
| Flap | Variant-correct hinge/track rotation center | X along span |
| Slat | Leading-edge track reference; translate before any small rotation | X along span |
| Spoiler | Forward hinge line | X along span |
| Engine fan | Engine centerline at fan disc | Z along engine axis |
| Reverser | Nacelle centerline; translation only unless reference requires doors | Z along engine axis |
| Gear strut | Trunnion center | Axis through both trunnion bearings |
| Gear door | Actual door hinge line | Along door hinge |
| Gear truck | Truck beam pivot | X through bogie pivot |
| Wheel | Axle center | X through axle |
| 777-9 folding tip | Full-span certified fold hinge | Along the real hinge line |

Do not place pivots at object bounding-box centers. The animation installer must read the imported `PIVOT` attachments and create the existing `BaseLocalCF`, `RetractedLocalCF`, hinge, and visual-channel data without changing flight forces.

## Materials and UVs

Use these stable material slots:

- `MAT_AirframePaint`
- `MAT_Livery`
- `MAT_BareMetal`
- `MAT_CockpitGlass`
- `MAT_CabinGlass`
- `MAT_Rubber`
- `MAT_GearMetal`
- `MAT_Brake`
- `MAT_EngineInterior`
- `MAT_HeatShield`
- `MAT_LightLens`

Use non-overlapping UVs unless a deliberately mirrored generic part has no livery or readable detail. Texture sets are `ATW_<CODE>_Exterior`, `ATW_<CODE>_Glass`, `ATW_<CODE>_Gear`, and `ATW_<CODE>_Interior`, each with `_BaseColor`, `_Normal`, `_Roughness`, and `_Metalness` maps as applicable. No asset IDs are specified here. Avoid baked highlights; reflections and roughness belong in PBR maps and Studio lighting.

## Attachments that must survive

Preserve or recreate at identical model-local transforms:

- `ATT_Root`
- `ATT_CameraCockpit`
- `ATT_CameraBelly` below the center fuselage and ahead of the main gear so the rear gear remains visible
- `ATT_Nav_L/R`, `ATT_StrobeTail`, `ATT_BeaconTop/Bottom`, `ATT_Landing_L/R`
- `ATT_Engine_01…04`
- `ATT_GearContact_Nose`, `ATT_GearContact_Main_L/R`
- every current seat, re-entry prompt, boarding attachment, door attachment, engine emitter/audio anchor, and script-referenced instance not explicitly superseded by this contract

Before installation, search all scripts for every legacy instance name. If a required legacy name has no manifest mapping, stop and report it; do not rename by guesswork.

## Objects that remain Roblox physics Parts

Keep the existing `Root`, `PilotSeat`, network-ownership assembly, re-entry/boarding trigger, camera anchors, and simple invisible collision proxies as Roblox instances. Use a small number of box/hull collision Parts for fuselage, wings, and gear contact. Visual MeshParts are `Massless = true`, `CanCollide = false`, and unanchored. Static visuals weld to `Root`; flight controls, fans, gear, doors, wheels, and spoilers do not receive static welds.

## Geometry and performance budget

Roblox limits each individual mesh dependency to 20,000 triangles. These are production caps, not measurements of the current model:

| Object category | Maximum triangles per object |
|---|---:|
| Fuselage, nose, or tail cone | 14,000 |
| Wing or horizontal stabilizer | 8,000 |
| Fin | 6,000 |
| Nacelle or pylon | 7,000 |
| Major control surface | 3,000 |
| Gear strut/truck or door | 4,000 |
| Tire/wheel assembly | 3,500 |
| Small fairing or effect shell | 1,500 |

Use clean quad topology in Blender, triangulate at export, remove N-gons, merge accidental duplicate vertices, recalculate normals, and provide LODs for distant traffic. The validator cannot read triangle counts through Roblox Lua, so importer review is mandatory. See [Roblox general modeling specifications](https://create.roblox.com/docs/art/modeling/specifications) and [Roblox model requirements](https://create.roblox.com/docs/parts/models).

## Export and import

1. In Blender, keep each aircraft in its own collection and set scene units consistently. Apply scale and rotation before final export.
2. Export selected objects as FBX. Use `Apply Scalings: FBX Unit Scale`, `Forward: Z Forward`, and `Up: Y Up`, following [Roblox's Blender guidance](https://create.roblox.com/docs/art/blender).
3. In Studio 3D Importer, keep `Merge Meshes` off, preserve imported pivots, import into a staging folder, and make no live-aircraft replacement yet.
4. Confirm the preview points nose-first toward Roblox local -Z. If it does not, correct the Blender collection once; never rotate individual imported pieces to compensate.
5. Set the staging model's `AircraftCode`, `PrimaryPart = Root`, and run the validator. Verify the importer reports fewer than 20,000 triangles for every object.
6. Check front, top, side, three-quarter, gear-down, gear-up, flap, spoiler, rudder, elevator, fan, wheel-spin, and belly-camera views.

## Validation usage

Run manually in Studio after selecting the staging Model:

```lua
local Selection = game:GetService("Selection")
local Validator = require(game.ReplicatedStorage.SkyDeck.AircraftMeshValidator)
local model = Selection:Get()[1]
local report = Validator.Validate(model, model:GetAttribute("AircraftCode"))
Validator.PrintReport(report)
```

`AircraftMeshValidator` reports missing objects, bad names, missing pivots or attachments, missing/wrong PrimaryPart, visual collisions, visual mass, accidental anchoring, wrong wheel count, tire proportions, and bounding-box scale. It intentionally never edits the target.

## Reimport and rollback

1. Before installation, clone the full live runtime aircraft to `ServerStorage/<AircraftName> BeforeMeshReplacement`, set all backup scripts disabled, and mark the model `NonRunningBackup = true`.
2. Record the old model path, attributes, PrimaryPart, pivot, bounding box, attachments, seats, prompts, welds, constraints, collision proxies, and script-name dependencies.
3. Replace only the `Visual` contents after the staging import passes. Preserve `Root`, `Controls`, `Collision`, `Effects`, `Interior`, seats, scripts, network ownership, flight state, and aerodynamics.
4. Copy/validate attachment transforms, install moving objects through the existing visual controller, and run server/client tests with identical flight inputs. Flight behavior must remain numerically unchanged.
5. Reimport updates with unchanged object names and pivots. A renamed object is treated as a new dependency and must pass the full validation again.
6. If any validation, startup, entry, animation, collision, or flight test fails, remove the new visual container, clone the backup to the original parent/path, restore its pivot and attributes, and re-enable only the scripts that were enabled before backup.

No Blender `.blend` or FBX was generated because Blender is not installed in this workspace and no approved reference drawings/mesh inputs were supplied. This document, the manifest, and the validator are the safe handoff for that production step.

# Around the World V27

V27 focuses on the aircraft tires and nose, the minimap marker, multi-runway layout, and a safe data-driven PBR workflow.

## Aircraft tires

- Removed the fixed 0.34-stud nose-tire and 0.42-stud main-tire widths.
- Tire width is now derived from each variant's recorded real tire width-to-diameter ratio in `AircraftMeshManifest`.
- A220-300 and 777-9 keep clearly labeled proportional fallbacks because their exact application data is still awaiting verification.
- Wheel diameter, wheel contact height, aircraft spawn height, landing logic, and wheel counts were not changed.
- Paired-wheel spacing, axles, truck beams, hubs, brake discs, and calipers now fit the thicker tires.
- Each tire has three subtle circumferential tread bands instead of two widely separated bands.

## Nose visual pass

The earlier numbered nose list was interpreted as the requested windshield/framing, radome/chin shaping, and small realism-detail passes:

- cockpit glass is slightly recessed within the existing frames using family-specific values;
- three crown and three chin blend sections smooth the windshield-to-radome transition;
- the chin fairing fullness now follows the aircraft family;
- radomes have four subtle lightning-diverter strips;
- both sides have angle-of-attack vanes and avionics access panels, with a left-side ice-detector probe.

These are cosmetic, massless, non-collidable parts. Flight behavior and collision proxies are unchanged.

## Airports and minimap

- At every multi-runway airport, runway 2 is shifted 260 studs forward and runway 3 is shifted 260 studs aft.
- Parallel taxiways follow their runway; inter-runway connectors are diagonal so the complete movement area remains connected.
- The shared runway placement table drives live pavement, touchdown detection, world protection, and the bird's-eye map.
- The player direction pointer is 20% smaller, but retains its compact concave-arrow silhouette and clear heading rotation.

## Configurable PBR materials

- Added nine named material classes: PaintedFuselage, BareMetal, Wings, EngineNacelles, RubberTires, CockpitWindows, PassengerWindows, InteriorPanels, and InstrumentScreens.
- Every class exposes ColorMap, NormalMap, RoughnessMap, MetalnessMap, and EmissiveMap fields. Only appropriate fields are reported as required for each class.
- Empty fields are intentional; no Roblox asset IDs were invented or borrowed.
- `Inspect(model)` audits MeshParts, TextureIDs, SurfaceAppearance maps, duplicate appearances, and material assignments.
- `Apply(model)` reuses an existing SurfaceAppearance, never overwrites an existing TextureID or map ID, and creates no duplicate SurfaceAppearance when called repeatedly.
- Roblox SurfaceAppearance has no native emissive slot. V27 stores a configured screen emissive map in the `PBREmissiveMap` attribute for a screen/effects workflow and uses a restrained Neon fallback for instrument screens.

See `V27_PBR_MATERIAL_REPORT.md` for the inspection result and texture-authoring checklist.

## Test checklist

1. Open `Around-the-World-V27.rbxlx` and build the editable V27 world from the Command Bar.
2. Spawn a 737, 757, 767, A350, 777, and A380; inspect main and nose tire thickness from front, side, and belly views.
3. Retract and extend the landing gear and confirm paired tires do not overlap.
4. Inspect the cockpit/radome from front and three-quarter views for floating details or clipping.
5. Fly over Sunport or Skyline and compare staggered runway pavement with the minimap.
6. Land on each staggered runway and confirm touchdown/runway recognition still works.
7. Re-run the PBR apply function on a test imported MeshPart twice and confirm only one SurfaceAppearance exists.

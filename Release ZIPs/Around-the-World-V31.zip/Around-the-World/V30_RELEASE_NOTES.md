# Around the World V30

## Green Grass Airport

- Added `GGA — Green Grass Airport` on Greenhaven Island southwest of Alpine Ridge.
- Verified a conservative water margin between Greenhaven and Alpine's maximum coastline envelopes.
- GGA includes two intersecting runways, seven gates, a connected taxi/apron system, terminal, tower, roads, 32 generated buildings, and a 72-tree target.
- Low terrain, buildings, and trees use the shared rotated-runway exclusion tests and remain outside both approach paths.

## Runway placement variation

- `AirportLayout.RunwayPlacements` now supplies a heading delta as well as lateral and longitudinal offsets.
- Sunport's second runway crosses its main and third parallel runway, inspired by the supplied mixed parallel/crossing layout reference.
- Coral Bay and Green Grass use two-runway crossing layouts.
- Ember International and Skyline International retain staggered parallel layouts for variety.
- Every runway gets its actual magnetic-style designation from its effective heading.
- Rotated runway data is shared by pavement, shoulders, stopways, markings, PAPI/approach lights, taxi connectors, minimap runway/lineup graphics, touchdown detection, airport reserves, scenery rejection, and terrain rejection.
- Additional runway surfaces are lifted by only 0.025 studs as a visual z-fighting guard at intersections; the offset is too small to create a gameplay step and flight physics are unchanged.

## A380 cockpit re-entry

- The former prompt was centered on the pilot seat. On the A380, its large fuselage and high ground stance could place a player outside the prompt's 18-stud activation distance after exiting.
- Every player aircraft now has invisible left and right `CockpitEntryAnchor` Parts beside the forward passenger-door area at an apron-accessible height.
- Each anchor owns an `EnterCockpitPrompt` and a direct `PilotSeatReference`; prompt distance scales safely with fuselage radius.
- Prompts remain disabled while the seat is occupied and continue to enforce aircraft ownership and empty-seat checks on the server.
- No seat, control, mass, aerodynamics, or flight behavior was changed.

## Aircraft visual and livery review

- `V30_AIRCRAFT_VISUAL_UV_REVIEW.md` is the required non-destructive first-pass report.
- The current aircraft exterior is procedural Part/WedgePart/SpecialMesh geometry with no paintable continuous UV set, no aircraft MeshParts, and no SurfaceAppearance maps or TextureIDs.
- No livery was painted because the exact model path, approved concept name, authorized real-airline assets, and verified non-mirrored UV template are missing.
- The report includes exact Blender UV-export instructions, likely visual/performance risks, recommended RenderFidelity/LOD policy, count limitations, and the approval checklist required before an aircraft correction or livery pass.

## Test checklist

1. Build the V30 edit-mode world and confirm `GGA — Green Grass Airport` appears southwest of Alpine with open water between the islands.
2. Inspect GGA's seven gates, two intersecting runways, taxi connections, and dense tree coverage.
3. Inspect Sunport and Coral Bay from above; verify the rotated runway surfaces, markings, designations, lighting, and map alignment guides agree.
4. Confirm Ember and Skyline remain staggered parallel systems.
5. Land on each rotated runway and verify touchdown detection and rollout remain normal.
6. Spawn an A380, exit the pilot seat, walk or fall to apron level, and verify an `Enter cockpit` prompt appears near either forward side.
7. Re-enter with `E`, then repeat on a narrow-body aircraft and confirm ownership/occupied-seat rejection still works.
8. Check Output for errors. Flight behavior should match V29 because the changes are world geometry, access prompts, and audit documentation only.

# Around the World V29

V29 focuses on long-range visual navigation and subtle, scalable aircraft effects. It does not change lift, thrust, drag, mass, handling, controls, or touchdown physics.

## Detailed world map

- The minimap samples `AirportLayout`'s real island-boundary function, so the map coastline and generated island shapes use the same source data.
- Each island now has a sand rim, detailed coastline, interior contour, and deterministic terrain/city dots while retaining clear water separation.
- Every runway is drawn from its exact shared placement and heading data.
- Six restrained magenta dashed extensions project from both ends of every runway to help pilots establish the final approach centerline.
- The former arrow is completely removed. The player marker is a 24-pixel original yellow top-down aircraft silhouette with a dark outline, swept wings, tailplanes, and true-heading rotation.
- No PTFS map texture, aircraft icon, or other game asset is copied; the supplied pictures were used only as functional and silhouette references.

## Attachment-driven aircraft effects

- `AircraftEffectsConfig.lua` provides aircraft/profile-specific engine counts, light-position offsets, flash patterns, thresholds, rates, minimum quality levels, and draw distances.
- Lights are parented to named Attachments at the left/right wingtips, tail, upper/lower fuselage, wing/root, nose/taxi, inspection, and logo-light positions.
- Particle emitters are parented to named Attachments on the engine exhausts, wingtips, landing-gear wheels, and local rain volume.
- Lighting includes red left navigation, green right navigation, white tail navigation, white wingtip/tail strobes, red upper/lower anti-collision beacons, and landing, taxi, turnoff, inspection, and logo lights.
- Engine presentation includes delta-time-smoothed fan blur, low-rate subtle exhaust/heat haze, and altitude/power/speed-gated contrails.
- Wingtip condensation requires sufficient humidity, flap, speed, altitude, and airborne state.
- Tire smoke is a brief burst only on a newly detected sufficiently hard main-gear touchdown, with load/speed thresholds and a cooldown.
- Wet-runway spray and local rain remain quality/distance gated.

## Performance and authority

- The client scans each aircraft once and caches its light, emitter, and fan-blur descendants.
- Map geometry is created once; no map object is rebuilt per frame.
- Effect update folders, world state, and quality setting reads are cached.
- Effects switch off beyond configured distances and below configured quality settings.
- Destroying or removing an aircraft disables its effects and disconnects its controller connection.
- All states come from the existing server-authoritative aircraft and weather Attributes. The effects layer does not add controls or change flight behavior.

## Test checklist

1. Open `Around-the-World-V29.rbxlx`, build the editable world from the Command Bar, and press Play.
2. Confirm each island remains visually separate and its minimap coastline resembles its world shape.
3. Approach several runways and confirm their magenta dashed guides follow the runway centerline at both ends.
4. Turn through all headings and confirm the yellow map aircraft remains a recognizable top-down plane rather than a rectangle or arrow.
5. Toggle exterior lights with `L` and inspect red/green/white navigation lights, beacon/strobe patterns, and landing/taxi lights.
6. Test low and high power, high altitude, humid landing configuration, rain/wet runway, and a firm main-gear touchdown.
7. Confirm effects become cheaper or invisible at long range and that despawned aircraft leave no running effect connections.

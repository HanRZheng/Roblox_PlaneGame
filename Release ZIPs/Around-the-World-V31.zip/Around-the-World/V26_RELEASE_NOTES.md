# Around the World V26

## Playable world changes

- All seven island landmasses now use different non-circular profiles based on the supplied aerial references: elongated/tapered, ridge, broad-lobed, bay-lobed, or asymmetric multi-lobed.
- Island aspect ratios and radial variation are area-normalized, and the closest profiles are rotated to preserve clear water channels.
- Airport land reserves still guarantee continuous land under every runway, stopway, taxiway, apron, terminal, and gate.
- Water-contact and off-runway landing detection now use the irregular coastline test instead of the obsolete circular-radius test.
- Added Skyline Regional (`SKR`) on Metropolis Island: one 2,900-stud runway, a connected taxiway/apron, three gates, terminal interiors, roads, and restrained regional-airport scenery.
- Skyline Regional shares Skyline International's island instead of generating an overlapping second landmass.
- The bird's-eye map renders the new island silhouettes and both Skyline airports.
- Replaced the unsupported Unicode map arrow with a compact broad concave pointer made only from GUI Frames, preventing the rectangle/missing-glyph bug.

## Aircraft technical-art package

- Added `AIRCRAFT_MESH_REPLACEMENT_SPEC_V26.md` with the required Blender object layout, variant envelopes, nose/tail standards, pivots, material slots, UV sets, collision separation, triangle caps, attachment preservation, reimport, and rollback procedure.
- Added `AircraftMeshManifest`, covering all 20 exact variants, engine/wheel counts, required object names, project scale, and aircraft-tire dimensions from aviation tire application data where an exact entry was available.
- Added a non-running `AircraftMeshValidator`. It reports missing names, pivots, attachments, PrimaryPart, anchored visuals, collisions, mass, bad scale, wheel count, and tires that are too thin.
- A220, 777-9, and E2 tire entries remain explicitly marked for exact AMM confirmation rather than using invented data.
- No current aircraft exterior or flight physics was modified during this task. Blender is not installed in this workspace, so no unverified `.blend` or FBX was fabricated.

## Test checklist

1. Open `Around-the-World-V26.rbxlx`, run the edit-mode world builder, and inspect every island from above.
2. Confirm water is visible between all separate islands and that no airport surface is in the ocean.
3. Spawn at `SKR`, taxi across its apron/taxiway, and verify all three gates and the runway are usable.
4. Fly from `SKR` to `SKY`; confirm the map shows two separate airport points on one continuous Metropolis Island.
5. Rotate through north, east, south, and west headings and confirm the map pointer remains a compact arrow rather than a rectangle.
6. For future imported aircraft, run `AircraftMeshValidator` in a staging folder before any live visual swap.
